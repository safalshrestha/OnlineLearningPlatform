<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class admin extends CI_Controller {

	public function index()
	{
		$data['user'] = $this->session->userdata("email");
		$this->load->view('index', $data);
	}
	
	public function login()
	{
		error_reporting(0);
		//$this->load->view('welcome_message');
		$this->input->post('email');
		$this->input->post('password');
		
		$this->load->helper(array('form', 'url'));
		
		$this->load->library('form_validation');
		
		$this->form_validation->set_rules('email','email','trim|required|xss_clean|valid_email');
		$this->form_validation->set_rules('password','password','trim|required|xss_clean|min_length[6]');
		
		if ($this->form_validation->run()) {

			//$this->db->insert('users', array('email'=>$this->input->post('email'), ');
			$data['status'] = "";
			$this->db->where("email",$this->input->post('email'));
			$this->db->where("password",md5($this->input->post('password'))); //no salting yet
			$query = $this->db->get("users");

			$options = array("email"=>$this->input->post('email'), "password"=>$this->input->post('password') );

			if($this->users_model->getUsers($options)) {
				$this->session->set_userdata('email',$this->input->post('email'));
				$row = $query->row();//first row of the query
				$this->session->set_userdata('privilege', $row->privilege);
				$this->welcome();

			}else{
				$data['page'] = "login_form";
				$data['status'] = "Login Mismatch";
				$this->load->view('index', $data);
			}
		}
		else {
			$data['page'] = "login_form";
			$data['status'] = "Invalid data";
			$this->load->view('index', $data);
		}
	}
	
	public function login_form()
	{
		$data["page"] = "login_form";
		$data['status'] = "";
		$data['nav'] = "";
		$this->load->view('index',$data);
	}


	public function logout(){
		$this->session->unset_userdata("email");
		$this->session->unset_userdata("privilege");
	}
	public function forgotpassword_form(){
		$data['page'] = 'forgotpassword';
		$data['status'] = '';
        $this->load->view('index', $data);
    }
    public function retrievepassword(){
        $this->form_validation->set_rules('email', 'email', 'trim|required|xss_clean|valid_email');

        if($this->form_validation->run()){
            $options['email'] = trim($this->input->post('email'));
            $query = $this->users_model->GetUsers($options);
            if(count($query) > 0){
                $uniqueId = $this->users_model->generatePassword();

                $data['email'] = $this->input->post('email');
                $data['password'] = $uniqueId;
                $this->users_model->UpdateUser($data);

                $query2 = $this->db->get_where("newsletters", array('id'=>11))->row(0);

                $provider = $this->db->get('providers')->row(0);
                $options['from'] = $provider->email;
                $options['name'] = $provider->name;
                $options['to'] = $this->input->post('email');
                $options['subject'] = $query2->subject;
                $options['message'] = str_replace(array('[USERNAME]', '[SITEURL]', '[PASSWORD]'),
                    array($this->session->userdata('userId'), 'http:'.site_url(), $uniqueId ), $query2->body);
                $this->users_model->sendMail($options);

                $data['page'] = 'forgotpassword';
                $data['status'] = 'New password sent to your mailbox.';
                
                $this->load->view('index', $data);
            }else{

                $data['page'] = 'forgotpassword';
                //$data['pagetitle'] = 'Instant World';
                //$data['status'] = 'Password Retrieve';
                $data['status'] = 'Please try again..';
                //$this->_setTracker("Password retrieval error.");
                $this->load->view('index', $data);
            }
        }else $this->forgotpassword_form();
    }
    

    //navigation menu based on user privilege
    public function _genNavigation(){
    	
    	$navs = $this->db->get_where("nav", array("privilege"=>$this->users_model->getPrivilege()))->result();
    	return $navs;
    }

    


	public function welcome(){
		$data['page'] = "welcome";
		$data['status'] = "<p class='text-info'> Login success </p>";
		$data['nav'] = $this->_genNavigation();
		$data['priv'] = $this->users_model->getPrivilege();

		switch ($this->users_model->getPrivilege()) {
			case 1:
				//admin
				$this->users_model->adminGuard();
				break;
			case 2:
				//faculty head
				$this->users_model->facultyGuard();
				break;
			case 3:
				$this->users_model->lecturerGuard();
				//lecturers
				break;
			case 9:
				//students
				$this->users_model->sessionGuard();
				break;
			case 8:
				//TODO: parents
				$this->users_model->sessionGuard();

				break;
			default:
				echo "Nothing here";
				die();
				break;
		}

		
		$this->load->view('index', $data);	//passing variable to view
	}

	public function changePassword() {
		if ($this->input->post("npassword") == $this->input->post("cnpassword")) return false;
		else {
			if ($this->input->post('id') || $this->input->post('npassword') || $this->input->post('cpassword')) {
				$option['id'] = $this->input->post("id");
				$option['password'] = $this->input->post("cpassword");

				if($this->users_model->getUsers($options)) {
					$data['id'] = $this->input->post('id');
					$data['password'] = $this->input->post('npassword');
					$this->users_model->changePassword($data);
				}
				else return false;
			}
		}
	}

	

	//single user register
	public function register($options = array()){
		if(!$options['email']) return false;
		if(!$options['privilege']) return false;
		
		$options['id'] = $this->users_model->getUniqueUserId();
        $options['password'] = md5($this->users_model->generatePassword());

		if($this->users_model->AddUser($options)) return $options;
		//insert into subject_student table
	}

	//-------------------------------------------------------------------------------------------------------
	
	public function students(){
    	//add group users function + single user
   
    	$data['page'] = "admin/add_users";

    	$this->db->where("privilege", 8);
    	$data['users'] = $this->db->get("users")->result();

    	$data['faculty'] = $this->db->get("faculty")->result();
    	$data['courses'] = $this->db->get("courses")->result();
    	$data['batch'] = $this->db->get("batch")->result();
    	
    	$data['status'] = "";
    	$data['nav'] = $this->_genNavigation();
    	$this->load->view("index",$data);


    	//list recently added users

    	//list blocked users (fee not paid)

    }

    public function addStudents(){
		$options['email'] = $this->input->post('email');
		$options['privilege'] = $this->input->post('privilege');
		
		var_dump($options['privilege']);
		var_dump($options['email']);


		$credentials = $this->register($options);
		$data['student_id'] = $credentials['id'];
		//if(!$credentials['student_id'] || $data['student_id'] != "" || $data['student_id'] != 0){
		if(count($credentials) > 0){
			//assign subjects to student
			$subjects= $this->db->get_where("subjects", array("course_id"=>$this->input->post('course_id')))->result();
			$data['batch_id'] = $this->input->post('batch_id');
			
			foreach($subjects as $subject){
				$data['subject_id'] = $subject->id;
				$this->db->insert("student_subject", $data);
			}
			//email user
			/*
              $options['from'] = '';
              $options['name'] = '';
              $options['to'] = '';
              $options['subject'] = '';
              $options['message'] = '';
            */
            $options['from'] = "admin@eSiksha.com";
            $options['name'] = "eSiksha";
            $options['to'] = $options['email'];
            $options['subject'] = "Welcome to eSiksha";
            $options['message'] = "Your password is: ".$credentials['password'];
            $this->users_model->sendMail($options);



		}else echo "0"; //false

	}
	public function deleteStudents() {
		if($this->input->post('id')) {
			$options['id'] = $this->input->post('id');
		}
		else if($this->input->post('email')) {
			$options['email'] = $this->input->post('email');
		}
		else return false;

		$this->users_model->deleteStudents($options);
	}

    public function lecturers(){
    	//add group users function + single user
    	
    	$this->db->where("privilege", 5);
    	$data['users'] = $this->db->get("users")->result();

    	$data['page'] = "admin/add_lecturer";
    	$data['courses'] = $this->db->get("courses")->result();
    	$data['subjects'] = $this->db->get("subjects")->result();
    	
    	
    	$data['status'] = "";
    	$data['nav'] = $this->_genNavigation();
    	$this->load->view("index",$data);


    	//list recently added users

    	//list blocked users (fee not paid)
    }

    public function addLecturer(){
		$options['email'] = $this->input->post('email');
		$options['privilege'] = 5;
		$subjects = $this->input->post('subject');

		$data['lecturer_id'] = $this->register($options);

		if(!$data['lecturer_id'] || $data['lecturer_id'] != "" || $data['lecturer_id'] != 0){
			//assign subjects to student
			foreach ($subjects as $subject_id ) {
				$data['subject_id'] = $subject_id;
				$this->db->insert("subject_lecturer", $data);
			}
		}else echo "0"; //false

	}

	public function deleteLecturer() {
		if($this->input->post('id')) {
			$options['id'] = $this->input->post('id');
		}
		else if($this->input->post('email')) {
			$options['email'] = $this->input->post('email');
		}
		else return false;

		$this->users_model->deleteLecturer($options);
	}

	public function getAllSubjects(){
		$this->db->select("id, course_id, name");
		$subjects = $this->db->get("subjects")->result();

		echo json_encode($subjects);
	}


    public function admins(){
    	
    	//add group users function + single user
    	$this->db->where("privilege", 2);
    	$data['users'] = $this->db->get("users")->result();
    	
    	$data['page'] = "admin/add_admin";
    	$data['courses'] = $this->db->get("courses")->result();
    	$data['subjects'] = $this->db->get("subjects")->result();
    	
    	
    	$data['status'] = "";
    	$data['nav'] = $this->_genNavigation();
    	$this->load->view("index",$data);


    	//list recently added users

    	//list blocked users (fee not paid)
    }

    public function addHeads(){
		$options['email'] = $this->input->post('email');
		$options['privilege'] = 2;
		$courses = $this->input->post('course');
		echo $courses;

		$data['lecturer_id'] = $this->register($options);
		if(!$data['lecturer_id'] || $data['lecturer_id'] != "" || $data['lecturer_id'] != 0){
			//assign subjects to admin

			foreach ($courses as $course_id) {
				$this->db->select("id");
				$subjects = $this->db->get_where("subjects", array("course_id"=>$course_id))->result();
				var_dump($subjects);
				foreach ($subjects as $subject_id ) {
					$data['subject_id'] = $subject_id->id;
					$this->db->insert("subject_lecturer", $data);
				}
			}
			
		}else echo "0"; //false

	}

	public function deleteHead() {
		if($this->input->post('id')) {
			$option['id'] = $this->input->post('id');
		}
		else if($this->input->post('email')) {
			$options['email'] = $this->input->post('email');
		}
		else return false;

		$this->users_model->deleteLecturer($options);
	}

	
	//GET ALL COURSES FOR ADDING FACULTY ADMINS: NEEDED FOR 
	public function getAllCourses(){
		$this->db->select("id, faculty_id, name");
		$courses = $this->db->get("courses")->result();

		echo json_encode($courses);
	}

	//***************************************************************************
	//-----------------------------------------------------------------------------------------------------------

	//**************************************************************************************
	public function updateUser() {

		var_dump($_POST);

		if ($this->input->post('email') || $this->input->post('id')) {
			$option['id'] = $this->input->post("id");
			$option['email'] = $this->input->post("email");
			if($this->input->post("password") != null) $option['password'] = $this->input->post("password");
			$option['from'] = "admin";
			$this->users_model->updateUser($option);
		}
		else return false;
		
	}

	

	

	public function faculty(){
    	//add group users function + single user
    	
    	
    	$data['page'] = "admin/add_faculty";
    	$data['status'] = "";
    	$data['nav'] = $this->_genNavigation();
    	$data['faculty'] = $this->users_model->getFaculty();
    	$this->load->view("index",$data);

    }

    public function addFaculty(){
		$options['name'] = $this->input->post('name');
		
		if ($this->users_model->addFaculty($options)){
		}
		else echo "0";
	}

	public function deleteFaculty() {
		if($this->input->post('id')) {
			$options['id'] = $this->input->post('id');
		}
		else return false;

		$this->users_model->deleteFaculty($options);
	}

	public function updateFaculty(){
		if($this->input->post('id')) {
			$options['id'] = $this->input->post('id');
			$options['name'] = $this->input->post('name');
			$id = $this->input->post('id');
			Var_dump($options);
			if ($this->users_model->updateFaculty($options)) {
				$this->faculty();
			}

		}
	}

	public function searchFaculty() {
		if($this->input->post('name')) {
			$options['name'] = $this->input->post('name');
		}
		else return false;
		$data['page'] = "admin/add_faculty";
    	$data['status'] = "";
    	$data['nav'] = $this->_genNavigation();
    	$data['faculty'] = $this->users_model->searchFaculty($options);
    	$this->load->view("index",$data);

		
	}

    public function course(){
    	var_dump($this->input->post());
    	//add group users function + single user
    	
    	
    	$data['page'] = "admin/add_course";
    	$data['faculty'] = $this->db->get("faculty")->result();
    	$data['status'] = "";
    	$data['nav'] = $this->_genNavigation();
    	$data['courses'] = $this->users_model->getCourses();

    	$this->load->view("index",$data);


    	//list recently added users

    	//list blocked users (fee not paid)
    }

    public function addCourse(){
    	$options['id'] = $this->input->post('id');
		$options['faculty_id'] = $this->input->post('faculty_id');
		$options['name'] = $this->input->post('name');
		if ($this->users_model->addCourse($options)){
		}
		else echo "0";
	}

	public function deleteCourse() {
		if($this->input->post('id')) {
			$options['id'] = $this->input->post('id');
		}
		else return false;

		$this->users_model->deleteCourse($options);
	}

	public function updateCourse(){
		if($this->input->post('id')) {
			$options['id'] = $this->input->post('id');
			$options['faculty_id'] = $this->input->post('faculty_id');
			$options['name'] = $this->input->post('name');
			$id = $this->input->post('id');
			Var_dump($options);
			if ($this->users_model->updateCourses($options)) {
				$this->course();
			}

		}
	}

	public function searchCourse() {
		if($this->input->post('id')) {
			$options['id'] = $this->input->post('id');
		}
		else return false;
		$data['page'] = "admin/add_course";
    	$data['status'] = "";
    	$data['nav'] = $this->_genNavigation();
    	$data['courses'] = $this->users_model->searchCourse($options);
    	$this->load->view("index",$data);

		
	}

    public function subject(){
    	//add group users function + single user
    	
    	
    	$data['page'] = "admin/add_subject";
    	$data['faculty'] = $this->users_model->getFaculty();
    	$data['courses'] = $this->users_model->getCourses();
    	$data['subjects'] = $this->users_model->getSubject();
    	$data['status'] = "";
    	$data['nav'] = $this->_genNavigation();
    	$this->load->view("index",$data);


    	//list recently added users

    	//list blocked users (fee not paid)
    }

    public function addSubject(){
    	$options['course_id'] = $this->input->post('course_id');
		$options['name'] = $this->input->post('name');
		$options['status'] = $this->input->post('available');
		if ($this->users_model->addSubject($options)){
		}
		else echo "0";
	}

	public function deleteSubject() {
		if($this->input->post('id')) {
			$options['id'] = $this->input->post('id');
		}
		else return false;

		$this->users_model->deleteSubject($options);
	}

	public function updateSubject(){
		if($this->input->post('id')) {
			$options['id'] = $this->input->post('id');
			$options['course_id'] = $this->input->post('cid');
			$options['name'] = $this->input->post('name');
			$options['status'] = $this->input->post('state');
			$id = $this->input->post('id');
			Var_dump($options);
			if ($this->users_model->updateSubject($options)) {
				$this->subject();
			}

		}
	}

	public function searchSubject() {
		if($this->input->post('name')) {
			$options['name'] = $this->input->post('name');
		}
		else return false;
		$data['page'] = "admin/add_subject";
    	$data['status'] = "";
    	$data['nav'] = $this->_genNavigation();
    	$data['faculty'] = $this->users_model->getFaculty();
    	$data['courses'] = $this->users_model->getCourses();
    	$data['subjects'] = $this->users_model->searchSubject($options);
    	$this->load->view("index",$data);

		
	}

    public function batch(){
    	$data['page'] = "admin/add_batch";
    	$data['status'] = "";
    	$data['nav'] = $this->_genNavigation();
    	$data['batches'] = $this->users_model->getBatches();
    	$this->load->view("index",$data);
    }

    
	public function addBatch(){
    	$options['id'] = $this->input->post('id');
		$options['start_date'] = $this->input->post('start_date');
		$options['end_date'] = $this->input->post('end_date');
		$options['name'] = $this->input->post('name');
		if ($this->users_model->addBatch($options)){
		}
		else echo "0";
	}

	public function deleteBatch() {
		if($this->input->post('id')) {
			$options['id'] = $this->input->post('id');
		}
		else return false;

		$this->users_model->deleteBatch($options);
	}

	public function updateBatch(){
		if($this->input->post('id')) {
			$options['id'] = $this->input->post('id');
			$options['start_date'] = $this->input->post('start');
			$options['end_date'] = $this->input->post('end');
			$options['name'] = $this->input->post('name');
			$id = $this->input->post('id');
			Var_dump($options);
			if ($this->users_model->updateBatch($options)) {
				$this->batch();
			}

		}
	}

	 public function searchBatch(){
    	$data['page'] = "admin/add_batch";
    	$data['status'] = "";
    	$data['nav'] = $this->_genNavigation();
    	$data['batches'] = $this->users_model->searchBatch();
    	$this->load->view("index",$data);
    }

	public function notice(){
    	$data['page'] = "admin/add_notice";
    	$data['status'] = "";
    	$data['nav'] = $this->_genNavigation();
    	$data['notices'] = $this->users_model->getNotices();
    	$this->load->view("index",$data);
    }

    public function addNotice(){
		$options['title'] = $this->input->post('title');
		$options['content'] = $this->input->post('content');

		if ($this->users_model->addNotice($options)){
		}
		else echo "0";
	}

	public function deleteNotice() {
		if($this->input->post('id')) {
			$options['id'] = $this->input->post('id');
		}
		else return false;
		$this->users_model->deleteNotice($options);
		redirect('/admin/notice/', 'refresh');
	}

	public function viewNotice(){
		error_reporting(0);
		if ($this->input->post('id'))
		{
			$id = $this->input->post('id');
		}
			$data['page'] = "admin/view_notice";
			$data['status'] = "";
			$data['nav'] = "";
			$q = $this->db->get_where("notices", array("id"=> $id))->row(0);
		
			$data['id'] = $q->id;
			$data['timestamp'] = $q->timeStamp;
			$data['title'] = $q->title;
			$data['content'] = $q->content;
			$this->load->view("index", $data);
	}

	public function editNotice(){
		if($this->input->post('id')) {
			$options['id'] = $this->input->post('id');
			$options['title'] = $this->input->post('title');
			$options['content'] = $this->input->post('content');
			$id = $this->input->post('id');
			if ($this->users_model->editNotice($options)) {
				$this->viewNotice($id);
			}

		}
	}
	//Viewing and Editing Profiles////
	public function searchUser() {
		if ($this->input->post('email'))
		{
			$options['email'] = $this->input->post('email');
			$options['priv'] = $this->input->post('priv');
		}
		$data['page'] = "admin/add_users";

    	$data['users'] = $this->users_model->searchUser($options);
    	var_dump($data['users']);
    	$data['faculty'] = $this->users_model->getFaculty();
    	$data['courses'] = $this->users_model->getCourses();
    	$data['batch'] = $this->users_model->getBatches();
    	
    	$data['status'] = "";
    	$data['nav'] = $this->_genNavigation();
    	$this->load->view("index",$data);
	}
	
	//created to avoid errors, using same function to get post data as well as pass parameters.
	//Missing argument error whenever variable posted from form.
	public function userProfile2(){
		if ($this->input->post('id'))
		{
			$user_id = $this->input->post('id');
			$priv = $this->input->post('priv');
		}
		$this->userProfile($user_id, $priv);
	}


	public function userProfile($user_id, $priv){
			$data['page'] = "admin/user_profile";
			$data['status'] = "";
			$data['nav'] = $this->_genNavigation();

			if ($priv == 8 || $priv == 9) {
				$this->db->order_by("batch_id", "desc");
				$q = $this->db->get_where("student_subject", array("student_id"=> $user_id))->row(0);
				$subject_id = $q->subject_id;
				$batch_id = $q->batch_id;
				//QUERY FOR COURSE ID
				$q = $this->db->get_where("subjects", array("id"=>$subject_id))->row(0);
				$data['course'] = $q->course_id;
				//QUERY FOR LATEST BATCH SUBJECTS
				$data['subjects'] = $this->db->get_where("student_subject", array("batch_id"=>$batch_id , "student_id"=>$user_id))->result();
				$data['subject_name'] = $this->db->get("subjects")->result();
			}
			else if ($priv == 2 || $priv == 5) {
				$data['course'] = "Subjects Taught";
				$data['subjects'] = $this->db->get_where("subject_lecturer", array("lecturer_id"=>$user_id))->result();
				$data['subject_name'] = $this->db->get("subjects")->result();		
			}
			$data['priv'] = $priv;
			$data['users'] = $this->db->get_where("personal_details", array("user_id"=>$user_id ))->result();
			$this->load->view("index", $data);
	}

	public function editProfile(){
		if($this->input->post('id')) {
			$options['user_id'] = $this->input->post('id');
			$options['title'] = $this->input->post('title');
			$options['first_name'] = $this->input->post('first_name');
			$options['family_name'] = $this->input->post('family_name');
			$options['dob'] = $this->input->post('dob');
			$options['add1'] = $this->input->post('add1');
			$options['add2'] = $this->input->post('add2');
			$options['add3'] = $this->input->post('add3');
			$options['add4'] = $this->input->post('add4');
			$options['phone'] = $this->input->post('phone');
			$options['mobile'] = $this->input->post('mobile');
			$options['nationality'] = $this->input->post('nationality');
			$options['birth_country'] = $this->input->post('birth_country');
			$options['pps_no'] = $this->input->post('pps_no');
			$user_id = $this->input->post('id');
			$priv = $this->input->post('priv');
			Var_dump($options);
			if ($this->users_model->editProfile($options)) {
				$this->userProfile($user_id, $priv);
			}

		}


	}

	 
}