<div class="container">
	<div class="jumbotron">
        <h1>Manage Your Studies Online</h1>
        
        <img src="/assets/img/slide-01.jpg" alt="">
    </div>
    <br />
   	<div class="row-fluid">
        <div class="span4">
          <h2>Collect</h2>
          <p>Collect your course notes online. View or download it whenever you want. 
          	All the contents are properly managed according to the subject you are studying.</p>
        </div>
        <div class="span4">
          <h2>Submit</h2>
          <p>Submit your assignment online, get a quick reminder of your submission dates.
          	No need to rush behind your teacher. 
          </p>
       </div>
        <div class="span4">
          <h2>Grade</h2>
          <p>Get grades quicker online. </p>
          <p>Give exam without pen and paper and review your achivements.
          </p>
        </div>
      </div>
</div>
          